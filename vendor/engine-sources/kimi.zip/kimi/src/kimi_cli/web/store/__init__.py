"""Session storage."""
